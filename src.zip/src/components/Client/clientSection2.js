import React, { Component } from 'react';
import { Container,Row,Col,Nav,Card,Tab,Pagination } from 'react-bootstrap';
import { Link, StaticQuery, graphql } from 'gatsby'
import { FaAngleRight } from 'react-icons/fa'
import card1 from '../../images/home-card-1.png'
import card2 from '../../images/home-card-2.png'
import card3 from '../../images/home-card-3.png'
import card4 from '../../images/home-card-4.png'

class ClientSection2 extends Component {

     
    render() {
        
        return (
            <>
            <section className="client-section-2">
                <Container>
                    <Tab.Container id="left-tabs-example" defaultActiveKey="first">
                        <div className="p-0 border-0 d-block mb-50">
                            <Nav variant="pills" className="">
                                <Nav.Item>
                                    <Nav.Link eventKey="first" className="font-16">Business</Nav.Link>
                                </Nav.Item>
                                <Nav.Item>
                                    <Nav.Link eventKey="second" className="font-16">Consultant</Nav.Link>
                                </Nav.Item>
                                <Nav.Item>
                                    <Nav.Link eventKey="third" className="font-16">Cyber</Nav.Link>
                                </Nav.Item>
                                <Nav.Item>
                                    <Nav.Link eventKey="fourth" className="font-16">Data</Nav.Link>
                                </Nav.Item>
                                <Nav.Item>
                                    <Nav.Link eventKey="fifth" className="font-16">Design</Nav.Link>
                                </Nav.Item>
                                <Nav.Item>
                                    <Nav.Link eventKey="sixth" className="font-16">IT-Service</Nav.Link>
                                </Nav.Item>
                                <Nav.Item>
                                    <Nav.Link eventKey="seventh" className="font-16">Marketing</Nav.Link>
                                </Nav.Item>
                                <Nav.Item>
                                    <Nav.Link eventKey="eighth" className="font-16">Object</Nav.Link>
                                </Nav.Item>
                                <Nav.Item>
                                    <Nav.Link eventKey="ninth" className="font-16">Solution</Nav.Link>
                                </Nav.Item>
                            </Nav>
                        </div>
                        <Tab.Content className="text-left">
                            <Tab.Pane eventKey="first">
                                <Row>
                                    <Col xl={4} lg={4} md={6} sm={12} className="mb-30">
                                        <Card className="p-0 border-0">
                                            <Card.Img variant="top" src={card1} fluid />
                                            <Card.Body className="pl-0 pr-0 pb-0">
                                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                            </Card.Text>
                                            <Link to="/" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                    <Col xl={4} lg={4} md={6} sm={12} className="mb-30">
                                        <Card className="p-0 border-0">
                                            <Card.Img variant="top" src={card2} fluid />
                                            <Card.Body className="pl-0 pr-0 pb-0">
                                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                            </Card.Text>
                                            <Link to="/" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                    <Col xl={4} lg={4} md={6} sm={12} className="mb-30">
                                        <Card className="p-0 border-0">
                                            <Card.Img variant="top" src={card3} fluid />
                                            <Card.Body className="pl-0 pr-0 pb-0">
                                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                            </Card.Text>
                                            <Link to="/" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                    <Col xl={4} lg={4} md={6} sm={12} className="mb-30">
                                        <Card className="p-0 border-0">
                                            <Card.Img variant="top" src={card1} fluid />
                                            <Card.Body className="pl-0 pr-0 pb-0">
                                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                            </Card.Text>
                                            <Link to="/" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                    <Col xl={4} lg={4} md={6} sm={12} className="mb-30">
                                        <Card className="p-0 border-0">
                                            <Card.Img variant="top" src={card2} fluid />
                                            <Card.Body className="pl-0 pr-0 pb-0">
                                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                            </Card.Text>
                                            <Link to="/" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                    <Col xl={4} lg={4} md={6} sm={12} className="mb-30">
                                        <Card className="p-0 border-0">
                                            <Card.Img variant="top" src={card3} fluid />
                                            <Card.Body className="pl-0 pr-0 pb-0">
                                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                            </Card.Text>
                                            <Link to="/" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                                            </Card.Body>
                                        </Card>
                                    </Col>
                                </Row>
                                
                                <Pagination className="justify-content-center mt-4">
                                    <Pagination.Prev className="prev" />
                                    <Pagination.Item>{1}</Pagination.Item>
                                    <Pagination.Item active>{2}</Pagination.Item>
                                    <Pagination.Item>{3}</Pagination.Item>
                                    <Pagination.Next className="next"/>
                                </Pagination>
                            </Tab.Pane>
                            <Tab.Pane eventKey="second">
                                <h1>Consultant</h1>
                            </Tab.Pane>
                            <Tab.Pane eventKey="third">
                                <h1>Cyber</h1>
                            </Tab.Pane>
                            <Tab.Pane eventKey="fourth">
                                <h1>Data</h1>
                            </Tab.Pane>
                            <Tab.Pane eventKey="fifth">
                                <h1>Design</h1>
                            </Tab.Pane>
                            <Tab.Pane eventKey="sixth">
                                <h1>IT-Service</h1>
                            </Tab.Pane>
                            <Tab.Pane eventKey="seventh">
                                <h1>Marketing</h1>
                            </Tab.Pane>
                            <Tab.Pane eventKey="eighth">
                                <h1>Object</h1>
                            </Tab.Pane>
                            <Tab.Pane eventKey="ninth">
                                <h1>Solution</h1>
                            </Tab.Pane> 
                        </Tab.Content>
                    </Tab.Container>
                </Container>
            </section>
            </>
        );
    }
}

export default ClientSection2;
