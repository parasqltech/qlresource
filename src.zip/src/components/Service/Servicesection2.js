import React, { Component } from 'react';
import { Container } from 'react-bootstrap';
import { Link, StaticQuery, graphql } from 'gatsby'

class Servicesection2 extends Component {

     
    render() {
        return (
            <>
            
            
            <section className="service-section-2">
                <Container>
                    <div className="title mb-0">
                        <h2 className="text-center">Lorem ipsum dolor sit amet, consetetur</h2>
                        <p className="font- align-justify mb-0">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy 
                            eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam 
                            et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit 
                            amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt
                            ut labore et dolore magna aliquyam erat, sed diam voluptua.At vero eos et accusam et justo duo 
                            dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet</p>
                    </div>
                </Container>
            </section>

            </>
        );
    }
}

export default Servicesection2;
