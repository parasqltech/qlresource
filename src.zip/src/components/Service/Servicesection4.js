import React, { Component } from 'react';
import { Container,Image,Row,Col,Card,Button,ListGroup } from 'react-bootstrap';
import { Link, StaticQuery, graphql } from 'gatsby'
import { FaAngleRight } from 'react-icons/fa'
import service1 from '../../images/service-1.png'

class Servicesection3 extends Component {

     
    render() {
        
        return (
            <>
            <section className="service-section-4">
                  <Container>
                    <div className="title">
                      <h2 className="text-center">Lorem ipsum dolor sit?</h2>
                      <p className="text-center">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod</p>
                    </div>
                    <Row>
                      <Col xl={4} lg={4} md={12} className="mb-4 service-card">
                        <div className="service-block-two">
                           <div class="inner-box wow fadeInLeft  animated" >
                            <Card className="border-0">
                              <div className="icon-box">
                                <Card.Img variant="top" src={service1}  fluid />
                              </div>
                              <Card.Body className="p-0">
                                <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                                <Card.Text className=" font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                </Card.Text>
                                <Link to="/" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                              </Card.Body>
                            </Card>
                           <div class="shape-one"></div><div class="shape-two"></div><div class="shape-three"></div>
                          </div>
                        </div>
                      </Col>
                      <Col xl={4} lg={4} md={12} className="mb-4 service-card">
                        <div className="service-block-two">
                           <div class="inner-box wow fadeInLeft  animated" >
                            <Card className="border-0">
                              <div className="icon-box">
                                <Card.Img variant="top" src={service1}  fluid />
                              </div>
                              <Card.Body className="p-0">
                                <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                                <Card.Text className=" font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                </Card.Text>
                                <Link to="/" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                              </Card.Body>
                            </Card>
                           <div class="shape-one"></div><div class="shape-two"></div><div class="shape-three"></div>
                          </div>
                        </div>
                      </Col>
                      <Col xl={4} lg={4} md={12} className="mb-4 service-card">
                        <div className="service-block-two">
                           <div class="inner-box wow fadeInLeft  animated" >
                            <Card className="border-0">
                              <div className="icon-box">
                                <Card.Img variant="top" src={service1}  fluid />
                              </div>
                              <Card.Body className="p-0">
                                <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                                <Card.Text className=" font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                </Card.Text>
                                <Link to="/" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                              </Card.Body>
                            </Card>
                           <div class="shape-one"></div><div class="shape-two"></div><div class="shape-three"></div>
                          </div>
                        </div>
                      </Col>
                      <Col xl={4} lg={4} md={12} className="mb-4 service-card">
                        <div className="service-block-two">
                           <div class="inner-box wow fadeInLeft  animated" >
                            <Card className="border-0">
                              <div className="icon-box">
                                <Card.Img variant="top" src={service1}  fluid />
                              </div>
                              <Card.Body className="p-0">
                                <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                                <Card.Text className=" font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                </Card.Text>
                                <Link to="/" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                              </Card.Body>
                            </Card>
                           <div class="shape-one"></div><div class="shape-two"></div><div class="shape-three"></div>
                          </div>
                        </div>
                      </Col>
                      <Col xl={4} lg={4} md={12} className="mb-4 service-card">
                        <div className="service-block-two">
                           <div class="inner-box wow fadeInLeft  animated" >
                            <Card className="border-0">
                              <div className="icon-box">
                                <Card.Img variant="top" src={service1}  fluid />
                              </div>
                              <Card.Body className="p-0">
                                <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                                <Card.Text className=" font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                </Card.Text>
                                <Link to="/" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                              </Card.Body>
                            </Card>
                           <div class="shape-one"></div><div class="shape-two"></div><div class="shape-three"></div>
                          </div>
                        </div>
                      </Col>
                      <Col xl={4} lg={4} md={12} className="mb-4 service-card">
                        <div className="service-block-two">
                           <div class="inner-box wow fadeInLeft  animated" >
                            <Card className="border-0">
                              <div className="icon-box">
                                <Card.Img variant="top" src={service1}  fluid />
                              </div>
                              <Card.Body className="p-0">
                                <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                                <Card.Text className=" font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                                </Card.Text>
                                <Link to="/" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                              </Card.Body>
                            </Card>
                           <div class="shape-one"></div><div class="shape-two"></div><div class="shape-three"></div>
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </Container>
              </section>
            </>
        );
    }
}

export default Servicesection3;
