import React, { Component } from 'react';
import { Container,Accordion, Card, Button , Collapse } from 'react-bootstrap';
import { Link, StaticQuery, graphql } from 'gatsby'
class servicesection6 extends Component {

    handleToggle = (id) => {
		
        document.querySelectorAll('.card:not(.id'+id+')').forEach(function(button) {	
			if(!button.classList.contains(".id"+id)){
				button.classList.remove('active');
			}
		});
		
		if (document.querySelector(".id"+id).classList.contains('active')) {
		  document.querySelector(".id"+id).classList.remove('active');
		} else {
		  document.querySelector(".id"+id).classList.add('active');
		}
		
    } 
    
    render() {
        return (
            <>
            
            <section className="service-section-6">
                <Container>
                    <div className="title">
                      <h2 className="text-center">Lorem ipsum dolor sit?</h2>
                      <p className="text-center">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod</p>
                    </div>
                    
                    
                    <Accordion defaultActiveKey="">
                        <Card  className={"p-0 mb-4 id0"}>
                            <Card.Header>
                            <Accordion.Toggle className="font-18 font-semibold p-0" as={Button} onClick={() => {this.handleToggle(0)}} variant="link" eventKey="0">
                                Lorem ipsum dolor sit amet, consetetur
                            </Accordion.Toggle>
                            </Card.Header>
                            <Accordion.Collapse eventKey="0">
                            <Card.Body className="font-16">
                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor 
                                invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam 
                                et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est
                                Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                                diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea 
                                takimata sanctus est Lorem ipsum dolor
                            </Card.Body>
                            </Accordion.Collapse>
                        </Card>
                        <Card  className={"p-0 mb-4 id1"}>
                            <Card.Header>
                            <Accordion.Toggle className="font-18 font-semibold p-0" as={Button} onClick={() => {this.handleToggle(1)}} variant="link" eventKey="1">
                                Lorem ipsum dolor sit amet, consetetur
                            </Accordion.Toggle>
                            </Card.Header>
                            <Accordion.Collapse eventKey="1">
                            <Card.Body className="font-16">
                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor 
                                invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam 
                                et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est
                                Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                                diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea 
                                takimata sanctus est Lorem ipsum dolor
                            </Card.Body>
                            </Accordion.Collapse>
                        </Card>
                        <Card  className={"p-0 mb-4 id2"}>
                            <Card.Header>
                            <Accordion.Toggle className="font-18 font-semibold p-0" as={Button} onClick={() => {this.handleToggle(2)}} variant="link" eventKey="2">
                                Lorem ipsum dolor sit amet, consetetur
                            </Accordion.Toggle>
                            </Card.Header>
                            <Accordion.Collapse eventKey="2">
                            <Card.Body className="font-16">
                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor 
                                invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam 
                                et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est
                                Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                                diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea 
                                takimata sanctus est Lorem ipsum dolor
                            </Card.Body>
                            </Accordion.Collapse>
                        </Card>
                        
                        <Card  className={"p-0 mb-4 id3"}>
                            <Card.Header>
                            <Accordion.Toggle className="font-18 font-semibold p-0" as={Button} onClick={() => {this.handleToggle(3)}} variant="link" eventKey="3">
                                Lorem ipsum dolor sit amet, consetetur
                            </Accordion.Toggle>
                            </Card.Header>
                            <Accordion.Collapse eventKey="3">
                            <Card.Body className="font-16">
                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor 
                                invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam 
                                et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est
                                Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                                diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
                                At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea 
                                takimata sanctus est Lorem ipsum dolor
                            </Card.Body>
                            </Accordion.Collapse>
                        </Card>
                    </Accordion>

                  </Container>
              </section>

            </>
        );
    }
}

export default servicesection6;
