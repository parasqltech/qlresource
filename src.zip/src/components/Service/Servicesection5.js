import React, { Component } from 'react';
import { Container,Image,Card } from 'react-bootstrap';
import { Link, StaticQuery, graphql } from 'gatsby'
import { FaAngleRight } from 'react-icons/fa'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import card4 from '../../images/home-card-4.png'

class servicesection5 extends Component {

     
    render() {
        
      const settings = {
        dots: false,
        infinite: true,
        autoplay:false,
        autoplaySpeed:2000,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
            {
              breakpoint: 1000,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
          ]
      };
        return (
            <>
            
            <section className="service-section-5">
                <Container>
                    <div className="title">
                      <h2 className="text-center">Lorem ipsum dolor sit?</h2>
                      <p className="text-center">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod</p>
                    </div>
                  <Slider {...settings}>
                    <div>
                        <Card className="p-0 border-0">
                            <Card.Img variant="top" src={card4} fluid />
                            <Card.Body className="pl-0 pr-0 pb-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className=" font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                            </Card.Body>
                        </Card>
                    </div>
                    <div>
                        <Card className="p-0 border-0">
                            <Card.Img variant="top" src={card4} fluid />
                            <Card.Body className="pl-0 pr-0 pb-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className=" font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                            </Card.Body>
                        </Card>
                    </div>
                    <div>
                        <Card className="p-0 border-0">
                            <Card.Img variant="top" src={card4} fluid />
                            <Card.Body className="pl-0 pr-0 pb-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className="font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                            </Card.Body>
                        </Card>
                    </div>
                    <div>
                        <Card className="p-0 border-0">
                            <Card.Img variant="top" src={card4} fluid />
                            <Card.Body className="pl-0 pr-0 pb-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className="font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                            </Card.Body>
                        </Card>
                    </div>
                    <div>
                        <Card className="p-0 border-0">
                            <Card.Img variant="top" src={card4} fluid />
                            <Card.Body className="pl-0 pr-0 pb-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className="font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                            </Card.Body>
                        </Card>
                    </div>
                  </Slider>
                  </Container>
              </section>

            </>
        );
    }
}

export default servicesection5;
