import React, { Component } from 'react';
import { Container,Row,Col,Card,ListGroup,Form,InputGroup,FormControl,Image } from 'react-bootstrap';
import { Link, StaticQuery, graphql } from 'gatsby'
import { FaPinterestP, FaUserAlt, FaCommentAlt,FaFacebookF,FaTwitter,FaSearch } from 'react-icons/fa'
import card1 from '../../images/blog-section-2-card-1.png'
import imgbox from '../../images/sidebar-media.png'
class BlogDetailSection1 extends Component {

    render() {
        
        return (
            <>
            <section className="blog-details-section-1 blog-section-2">
                <Container>
                    <Row>
                        <Col xl={8} lg={7}>
                            <div className="blog-details-data">
                                <Card className="p-0 border-0 ">
                                    <h3 className="title-color font-22 font-bold">Lorem ipsum dolor</h3>
                                    <div className="card-footer d-flex justify-content-between align-items-center">
                                        <ListGroup as="ul" horizontal className="pb-3">
                                            <ListGroup.Item as="li" className="font-16 font-regular"><FaCommentAlt className="font-16 font-regular mr-2"/><span className="mr-1">3 </span> Comments</ListGroup.Item>
                                            <ListGroup.Item as="li" className="font-16 font-regular"><FaUserAlt className="font-16 font-regular mr-2"/>Admin</ListGroup.Item>
                                        </ListGroup>
                                    </div>
                                    <div className="position-relative">
                                        <Card.Img variant="top" src={card1} fluid />
                                        <div class="date align-items-center">
                                            <p className="font-25 font-bold mt-1 mb-0">
                                                22
                                            </p>
                                            <span className="font-16 font-regular mb-0">
                                                DEC
                                            </span>
                                        </div>
                                    </div>
                                    <Card.Body className="">
                                        <Card.Text className="">
                                            <p className="align-justify font-16-line-height font-regular">
                                            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.
                                            </p>
                                            <p className="align-justify font-16-line-height font-regular">
                                            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.
                                            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.
                                            </p>
                                        </Card.Text>
                                        <div className="card-footer align-items-center">
                                            <Row className="">
                                                <Col xl={6} lg={6} md={6} sm={12}>
                                                    <Form.Group className="mb-0 font-16 font-regular tagsList tagsList-horizontal">
                                                        <Form.Check
                                                            inline
                                                            type="checkbox"
                                                            id="tags11"
                                                            className="mb-0"
                                                            label="Business"
                                                        />
                                                        <Form.Check
                                                            inline
                                                            type="checkbox"
                                                            id="tags22"
                                                            className="mb-0"
                                                            label="Consult"
                                                        />
                                                        <Form.Check
                                                            inline
                                                            type="checkbox"
                                                            id="tags33"
                                                            className="mb-0"
                                                            label="Cyber"
                                                        />
                                                    </Form.Group>
                                                </Col>
                                                <Col xl={6} lg={6} md={6} sm={12}>
                                                    <ListGroup as="ul" horizontal>
                                                        <ListGroup.Item as="li" className="font-16 font-semibold">
                                                            Share this Post :
                                                        </ListGroup.Item>
                                                        <ListGroup.Item as="li" className="font-16 font-regular">
                                                            <Link to="/" className="color-cf font-22 font-regular">
                                                                <FaFacebookF/>
                                                            </Link>
                                                        </ListGroup.Item>
                                                        <ListGroup.Item as="li" className="font-16 font-regular">
                                                            <Link to="/" className="color-cf font-22 font-regular">
                                                                <FaTwitter/>
                                                            </Link>
                                                        </ListGroup.Item>
                                                        <ListGroup.Item as="li" className="font-16 font-regular">
                                                            <Link to="/" className="color-cf font-22 font-regular">
                                                                <FaPinterestP/>
                                                            </Link>
                                                        </ListGroup.Item>
                                                    </ListGroup>
                                                </Col>
                                            </Row>
                                        </div>
                                    </Card.Body>
                                </Card>
                            </div>
                        </Col>
                        <Col xl={4}  lg={5}>
                            <div className="side-sticky bg-gray p-4">
                                <Form>
                                    <div className="inner-sidebar mb-4">
                                        <Form.Group controlId="" className="mb-0">
                                            <Form.Label className="font-18 mb-3 font-bold">Search</Form.Label>
                                            <InputGroup className="mb-3">
                                                <FormControl className="main border-right-0"
                                                placeholder="Search..."
                                                aria-label=""
                                                aria-describedby="basic-addon2"
                                                />
                                                <InputGroup.Append className="border-left-0">
                                                <InputGroup.Text id="basic-addon2"><Link to="/" className="title-color"><FaSearch/></Link></InputGroup.Text>
                                                </InputGroup.Append>
                                            </InputGroup>
                                        </Form.Group>
                                    </div>
                                    <div className="inner-sidebar mb-4">
                                            <h3 className="font-18 mb-3 font-bold">Lorem ipsum</h3>
                                        <ListGroup as="ul" className="low-opacity">
                                            <ListGroup.Item as="li" className="font-18 justify-content-between d-flex align-items-center">
                                                <Link to="/" className="mr-1 color-303030 font-regular letter-space-1">Consulting</Link> <p className="mb-0 color-303030 font-regular">(1)</p>
                                            </ListGroup.Item> 
                                            <ListGroup.Item as="li" className="font-18 justify-content-between d-flex align-items-center">
                                                <Link to="/" className="mr-1 color-303030 font-regular letter-space-1">Cyber Data</Link> <p className="mb-0 color-303030 font-regular">(1)</p>
                                            </ListGroup.Item> 
                                            <ListGroup.Item as="li" className="font-18 justify-content-between d-flex align-items-center">
                                                <Link to="/" className="mr-1 color-303030 font-regular letter-space-1">Design</Link> <p className="mb-0 color-303030 font-regular">(1)</p>
                                            </ListGroup.Item> 
                                            <ListGroup.Item as="li" className="font-18 justify-content-between d-flex align-items-center">
                                                <Link to="/" className="mr-1 color-303030 font-regular letter-space-1">Digital</Link> <p className="mb-0 color-303030 font-regular">(1)</p>
                                            </ListGroup.Item> 
                                            <ListGroup.Item as="li" className="font-18 justify-content-between d-flex align-items-center">
                                                <Link to="/" className="mr-1 color-303030 font-regular letter-space-1">Marketing</Link> <p className="mb-0 color-303030 font-regular">(1)</p>
                                            </ListGroup.Item> 
                                            <ListGroup.Item as="li" className="font-18 justify-content-between d-flex align-items-center">
                                                <Link to="/" className="mr-1 color-303030 font-regular letter-space-1">Security</Link> <p className="mb-0 color-303030 font-regular">(1)</p>
                                            </ListGroup.Item> 
                                            <ListGroup.Item as="li" className="font-18 justify-content-between d-flex align-items-center">
                                                <Link to="/" className="mr-1 color-303030 font-regular letter-space-1">UI/UX Design</Link> <p className="mb-0 color-303030 font-regular">(1)</p>
                                            </ListGroup.Item>
                                        </ListGroup>
                                    </div>
                                    <div className="inner-media-sidebar mb-4">
                                        <h3 className="font-18 mb-3 font-bold">Lorem ipsum</h3>
                                        <ListGroup as="ul">
                                            <ListGroup.Item as="li" className="d-flex">
                                                    <div className="img-box-sidebar">
                                                    <Image src={imgbox} className="img-fluid border-0"/>
                                                    </div>
                                                    <div className="content-box-sidebar ">
                                                        <h2 className="font-18 font-bold title-color mb-1">Lorem ipsum dolor sit amet</h2>
                                                        <span className="font-14 font-regular">May 01, 2019</span>
                                                    </div>
                                            </ListGroup.Item> 
                                            <ListGroup.Item as="li" className="d-flex">
                                                    <div className="img-box-sidebar">
                                                    <Image src={imgbox} className="img-fluid border-0"/>
                                                    </div>
                                                    <div className="content-box-sidebar ">
                                                        <h2 className="font-18 font-bold title-color mb-1">Lorem ipsum dolor sit amet</h2>
                                                        <span className="font-14 font-regular">May 01, 2019</span>
                                                    </div>
                                            </ListGroup.Item> 
                                            <ListGroup.Item as="li" className="d-flex">
                                                    <div className="img-box-sidebar">
                                                    <Image src={imgbox} className="img-fluid border-0"/>
                                                    </div>
                                                    <div className="content-box-sidebar ">
                                                        <h2 className="font-18 font-bold title-color mb-1">Lorem ipsum dolor sit amet</h2>
                                                        <span className="font-14 font-regular">May 01, 2019</span>
                                                    </div>
                                            </ListGroup.Item> 
                                        </ListGroup>
                                    </div>
                                    
                                    <div className="inner-sidebar mb-0">
                                        <h3 className="font-18 mb-3 font-bold">Lorem ipsum</h3>
                                        <Form.Group className="mb-0 font-16 font-regular tagsList">
                                                <Form.Check
                                                    inline
                                                    type="checkbox"
                                                    id="tags1"
                                                    label="Business"
                                                />
                                                <Form.Check
                                                    inline
                                                    type="checkbox"
                                                    id="tags2"
                                                    label="Consult"
                                                />
                                                <Form.Check
                                                    inline
                                                    type="checkbox"
                                                    id="tags3"
                                                    label="Cyber"
                                                />
                                                <Form.Check
                                                    inline
                                                    type="checkbox"
                                                    id="tags4"
                                                    label="Data"
                                                />
                                                <Form.Check
                                                    inline
                                                    type="checkbox"
                                                    id="tags5"
                                                    label="Design"
                                                />
                                                <Form.Check
                                                    inline
                                                    type="checkbox"
                                                    id="tags6"
                                                    label="IT-Service"
                                                />
                                                <Form.Check
                                                    inline
                                                    type="checkbox"
                                                    id="tags7"
                                                    label="Marketing"
                                                />
                                                <Form.Check
                                                    inline
                                                    type="checkbox"
                                                    id="tags8"
                                                    label="Object"
                                                />
                                                <Form.Check
                                                    inline
                                                    type="checkbox"
                                                    id="tags9"
                                                    label="Solution"
                                                />
                                            </Form.Group>
                                    </div>
                                </Form>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            </>
        );
    }
}

export default BlogDetailSection1;
