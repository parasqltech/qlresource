import React, { Component } from 'react';
import { Container,Button } from 'react-bootstrap';
import { Link, StaticQuery, graphql } from 'gatsby'
import { FaAngleRight } from 'react-icons/fa'

class HomeSection6 extends Component {
     
    render() {
        
        return (
            <>

            <section className="home-section-6">
                  <Container>
                        <h2 className="font-60 font-bold mb-4">Lorem ipsum dolor sit amet, consetetur</h2>
                      <Button className="blue font-16 font-semibold">know more <FaAngleRight className="ml-2"/></Button>
                  </Container>
                </section>
            </>
        );
    }
}

export default HomeSection6;
