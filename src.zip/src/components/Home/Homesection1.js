import React, { Component } from 'react';
import { Container,Image,Row,Col,Button } from 'react-bootstrap';
import { FaAngleRight } from 'react-icons/fa'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import slider1 from '../../images/slider-1.png'
import slider2 from '../../images/mobile-slider.jpg'

function SampleNextArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ display: "block", borderRadius: "25px",border:"2px solid #fff",width:"50px",height:"50px",lineHeight:"46px",textAlign:"center" }}
        onClick={onClick}
      >
        </div>
    );
  }
  
  function SamplePrevArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ display: "block", borderRadius: "25px",border:"2px solid #fff",width:"50px",height:"50px",lineHeight:"46px",textAlign:"center" }}
        onClick={onClick} >
      </div>
    );
  }
class HomeSection1 extends Component {

     
    render() {
        const settings1 = {
            dots: true,
            infinite: true,
            speed: 500,
            slidesToShow: 1,
            slidesToScroll: 1,
            nextArrow: <SampleNextArrow />,
            prevArrow: <SamplePrevArrow />
          };
        return (
            <>
            
            <section className="home-section-1 main-padding-header">
                <Slider {...settings1}>
                    <div className="slider-data">
                       <Image src={slider1} className="img-fluid d-sm-inline d-none" />
                       <Image src={slider2} className="img-fluid d-sm-none d-inline" />
                       <div className="slider-inner-data">
                         <Container>
                          <Row>
                            <Col xl={8} lg={12} md={12}>
                                <h3 className="font-bold text-white">Lorem ipsum</h3>
                                <h2 className="text-white font-bold">Lorem ipsum dolor sit amet, </h2>
                                <h3 className="font-bold color-abf">Lorem ipsum dolor sit amet, consetetur</h3>
                                <Button className="white font-16 font-semibold">know more <FaAngleRight className="ml-2"/></Button>
                            </Col>
                          </Row>
                         </Container>
                       </div>
                    </div>
                    <div className="slider-data">
                       <Image src={slider1} className="img-fluid d-sm-inline d-none" />
                       <Image src={slider2} className="img-fluid d-sm-none d-inline" />
                       <div className="slider-inner-data">
                         <Container>
                          <Row>
                            <Col xl={8} lg={12} md={12}>
                                <h3 className="font-bold text-white">Lorem ipsum</h3>
                                <h2 className="text-white font-bold">Lorem ipsum dolor sit amet, </h2>
                                <h3 className="font-bold color-abf">Lorem ipsum dolor sit amet, consetetur</h3>
                                <Button className="white font-16 font-semibold">know more <FaAngleRight className="ml-2"/></Button>
                            </Col>
                          </Row>
                         </Container>
                       </div>
                    </div>
                    <div className="slider-data">
                       <Image src={slider1} className="img-fluid d-sm-inline d-none" />
                       <Image src={slider2} className="img-fluid d-sm-none d-inline" />
                       <div className="slider-inner-data">
                         <Container>
                          <Row>
                            <Col xl={8} lg={12} md={12}>
                                <h3 className="font-bold text-white">Lorem ipsum</h3>
                                <h2 className="text-white font-bold">Lorem ipsum dolor sit amet, </h2>
                                <h3 className="font-bold color-abf">Lorem ipsum dolor sit amet, consetetur</h3>
                                <Button className="white font-16 font-semibold">know more <FaAngleRight className="ml-2"/></Button>
                            </Col>
                          </Row>
                         </Container>
                       </div>
                    </div>
                </Slider>
            </section>
            </>
        );
    }
}

export default HomeSection1;
