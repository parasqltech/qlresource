import React, { Component } from 'react';
import { Container,Image,Row,Col,Card,Button,ListGroup } from 'react-bootstrap';
import { Link, StaticQuery, graphql } from 'gatsby'
import { FaAngleRight } from 'react-icons/fa'
import ourblog1 from '../../images/our-blog-1.png'
import ourblog2 from '../../images/our-blog-2.png'
import ourblog3 from '../../images/our-blog-3.png'

class HomeSection5 extends Component {

     
    render() {
        
        return (
            <>
            <section className="home-section-7">
                <Container>
                    <div className="title">
                        <h2 className="text-center font-bold">Our Blog</h2>
                    </div>
                    <Row>
                      <Col xl={6} lg={6} md={12}>
                      <Card className="p-0 border-0 md-mb-4">
                        <Card.Img variant="top" src={ourblog1} fluid />
                        <Card.Body className="">
                          <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                          <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                          </Card.Text>
                          <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                        </Card.Body>
                      </Card>
                      </Col>
                      <Col xl={6} lg={6} md={12}>
                      <Card className="p-0 border-0 mb-4">
                        <Card.Img variant="top" src={ourblog2} fluid />
                        <Card.Body className="">
                          <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                          <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                          </Card.Text>
                          <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                        </Card.Body>
                      </Card>
                      <Card className="p-0 border-0 mb-4">
                        <Card.Img variant="top" src={ourblog3} fluid />
                        <Card.Body className="">
                          <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                          <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                          </Card.Text>
                          <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                        </Card.Body>
                      </Card>
                      </Col>
                    </Row>
                </Container>
              </section>
            </>
        );
    }
}

export default HomeSection5;
