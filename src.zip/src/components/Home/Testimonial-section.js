import React, { Component } from 'react';
import { Container,Image,Row,Col,Card,Button,ListGroup } from 'react-bootstrap';
import { Link, StaticQuery, graphql } from 'gatsby'
import Layout from '../../components/Layout'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import user from '../../images/testimonioal-user.png'
import testbutton from '../../images/testimonial-button.png'

function SampleNextArrow1(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ display: "block", borderRadius: "25px",border:"2px solid #23A5DD",width:"50px",height:"50px",lineHeight:"50px",textAlign:"center" }}
        onClick={onClick}
      >
        </div>
    );
  }
  
  function SamplePrevArrow1(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ display: "block", borderRadius: "25px",border:"2px solid #23A5DD",width:"50px",height:"50px",lineHeight:"50px",textAlign:"center" }}
        onClick={onClick} >
      </div>
    );
  }
class Testimonialsection extends Component {
     
    render() {
      const settings3 = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay:true,
        autoplaySpeed:2500,
        nextArrow: <SampleNextArrow1 />,
        prevArrow: <SamplePrevArrow1 />
      };
        return (
            <>
            <section className="testimonial-section">
                  <Container>
                    <Slider {...settings3} className="testimonial-slider">
                      <div className="slider-data">
                        <Row className="justify-content-center">
                            <Col xl={8} lg={8} md={10} sm={12}>
                              <div className="position-relative test-img mb-4">
                                <Image src={user} className="img-fluid test-img"/>
                                <Image src={testbutton} className="img-fluid test-button"/>
                              </div>
                              <p className="font-24 font-regular mb-0">The image of a company is very important. Would you want to work with a consultation company whose office was in shambles</p>
                              <div className="justify-content-center d-flex">
                                <div className="line"></div>
                              </div>
                              <p className="font-bold font-22 font-uppercase mb-2">HASRUL HISHAM</p>
                              <span className="font-16 font-semibold">Lead Sofware</span>
                            </Col>
                        </Row>
                      </div>
                      <div className="slider-data">
                        <Row className="justify-content-center">
                            <Col xl={8} lg={7} md={10} sm={12}>
                              <div className="position-relative test-img mb-4">
                                <Image src={user} className="img-fluid test-img"/>
                                <Image src={testbutton} className="img-fluid test-button"/>
                              </div>
                              <p className="font-24 font-regular mb-0">The image of a company is very important. Would you want to work with a consultation company whose office was in shambles</p>
                              <div className="justify-content-center d-flex">
                                <div className="line"></div>
                              </div>
                              <p className="font-bold font-22 font-uppercase mb-2">HASRUL HISHAM</p>
                              <span className="font-16 font-semibold">Lead Sofware</span>
                            </Col>
                        </Row>
                      </div>
                      
                      <div className="slider-data">
                        <Row className="justify-content-center">
                            <Col xl={8} lg={8} md={10} sm={12}>
                              <div className="position-relative test-img mb-4">
                                <Image src={user} className="img-fluid test-img"/>
                                <Image src={testbutton} className="img-fluid test-button"/>
                              </div>
                              <p className="font-24 font-regular mb-0">The image of a company is very important. Would you want to work with a consultation company whose office was in shambles</p>
                              <div className="justify-content-center d-flex">
                                <div className="line"></div>
                              </div>
                              <p className="font-bold font-22 font-uppercase mb-2">HASRUL HISHAM</p>
                              <span className="font-16 font-semibold">Lead Sofware</span>
                            </Col>
                        </Row>
                      </div>
                  </Slider>
                  </Container>
                </section>
            </>
        );
    }
}

export default Testimonialsection;
