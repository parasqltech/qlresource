import React, { Component } from 'react';
import { Container,Image,Row,Col,Card,Button,ListGroup } from 'react-bootstrap';
import { Link, StaticQuery, graphql } from 'gatsby'
import { FaAngleRight } from 'react-icons/fa'

class HomeSection5 extends Component {

     
    render() {
        
        return (
            <>
            
            <section className="home-section-5">
                  <Container>
                    <div className="title">
                      <h2 className="text-center font-bold">Lorem ipsum dolor sit?</h2>
                      <p className="text-center mb-4">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod</p>
                    </div>
                    <Row className="mt-4">
                      <Col xl={3} lg={3} md={4} sm={12} className="mb-4">
                        <Card className="p-0 border-0 mb-4 md-mb-0">
                          <Card.Body className="p-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                          </Card.Body>
                        </Card>
                      </Col>
                      <Col xl={3} lg={3} md={4} sm={12} className="mb-4">
                        <Card className="p-0 border-0 mb-4 md-mb-0">
                          <Card.Body className="p-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                          </Card.Body>
                        </Card>
                      </Col>
                      <Col xl={3} lg={3} md={4} sm={12} className="mb-4">
                        <Card className="p-0 border-0 mb-4 md-mb-0">
                          <Card.Body className="p-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                          </Card.Body>
                        </Card>
                      </Col>
                      <Col xl={3} lg={3} md={4} sm={12} className="mb-4">
                        <Card className="p-0 border-0 mb-4 md-mb-0">
                          <Card.Body className="p-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                          </Card.Body>
                        </Card>
                      </Col>
                      <Col xl={3} lg={3} md={4} sm={12} className="mb-4">
                        <Card className="p-0 border-0 mb-4 md-mb-0">
                          <Card.Body className="p-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                          </Card.Body>
                        </Card>
                      </Col>
                      <Col xl={3} lg={3} md={4} sm={12} className="mb-4">
                        <Card className="p-0 border-0 mb-4 md-mb-0">
                          <Card.Body className="p-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                          </Card.Body>
                        </Card>
                      </Col>
                      <Col xl={3} lg={3} md={4} sm={12} className="mb-4">
                        <Card className="p-0 border-0 mb-4 md-mb-0">
                          <Card.Body className="p-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                          </Card.Body>
                        </Card>
                      </Col>
                      <Col xl={3} lg={3} md={4} sm={12} className="mb-4">
                        <Card className="p-0 border-0 mb-4 md-mb-0">
                          <Card.Body className="p-0">
                            <Card.Title className="font-22 font-bold">Lorem ipsum dolor</Card.Title>
                            <Card.Text className="line-break-2 font-14 font-regular">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua
                            </Card.Text>
                            <Link to="" className="nav-link p-0 font-18 font-regular">Learn more<FaAngleRight className="pl-2" /> </Link>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                  </Container>
              </section>
            </>
        );
    }
}

export default HomeSection5;
