import React, { Component } from 'react';
import { Container,Row,Col,Image } from 'react-bootstrap';
import { Link, StaticQuery, graphql } from 'gatsby'
import banner1 from '../../images/home-section-4-img-2.png'

class Aboutsection2 extends Component {

     
    render() {
        
        return (
            <>
            <section className="about-section-2">
                <Container>
                    <div className="title">
                      <h2 className="text-center font-bold">Lorem ipsum dolor sit?</h2>
                      <p className="text-left">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, </p>
                    </div>
                    <Row>
                        <Col xl={7} lg={7} md={7} className="sm-mb-2">
                            <div className="bg-gray p-4 md-p-0">
                                <p className="font-bold font-22 color-303030">Lorem ipsum dolor sit amet, consetetur</p>
                                <p className="font-18 font-regular mb-0 align-justify">
                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt 
                                ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo
                                 dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor 
                                 sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr.Lorem ipsum dolor sit amet, 
                                 consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna 
                                 aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet 
                                 clita kasd gubergren. 
                                </p>
                            </div>  
                        </Col>
                        <Col xl={5} lg={5} md={5}>
                          <Image src={banner1} className="img-fluid"/>
                        </Col>
                    </Row>
                </Container>
            </section>
            </>
        );
    }
}

export default Aboutsection2;
